import React from 'react';

const features = [
  {
    title: "Firewall",
    description: "Our system monitors and controls incoming and outgoing network traffic",
    icon: "path-to-icon",
  },
  {
    title: "Data Analysis",
    description: "Data mining, text analytics, business intelligence and data visualization",
    icon: "path-to-icon",
  },
  {
    title: "Encryption",
    description: "Information is encoded and can only be accessed with the encryption key",
    icon: "path-to-icon",
  },
  {
    title: "Protection",
    description: "Safeguarding important information from corruption, compromise or loss",
    icon: "path-to-icon",
  },
];

function App() {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center">
      <header className="w-full py-6 bg-white flex justify-between items-center px-8">
        <div className="text-blue-500 font-bold text-xl">ServerSharing</div>
      </header>
      <main className="w-full flex flex-col items-center px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Powerful and safe server hosting</h1>
          <p className="text-gray-600">Our revolutionary Cloud solution is powerful, simple, and surprisingly affordable. Harnessing the web has never been easier</p>
          <button className="mt-6 bg-blue-500 text-white py-2 px-4 rounded-full">Learn more</button>
        </div>
        <div className="w-full max-w-3xl">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center justify-between border-b py-4">
              <div className="flex items-center">
                <img src={feature.icon} alt={feature.title} className="h-12 w-12 mr-4" />
                <div>
                  <h2 className="text-lg font-bold text-gray-800">{feature.title}</h2>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              </div>
              <div className="text-blue-500 text-2xl">&rarr;</div>
            </div>
          ))}
        </div>
        <button className="mt-8 bg-blue-500 text-white py-2 px-6 rounded-full">Explore more about ServerSharing</button>
      </main>
    </div>
  );
}

export default App;
